# Dictionary and its default functions.
person = {'name': 'xyz', 'age': 22, 'salary': 3500.0}

#a) items function
print(person.items())

#b) get function
print('name of person is:', person.get('name'))

#c) keys function
print(person.keys())

#d) copy function
newdict = person.copy()
print('Orignal dictionary: ', person)
print('New dictionary: ', newdict)

#e) setdefault function
department= person.setdefault('department', 'production')
print('person = ', person)
print('department = ', department)

#f) update function
d1 = {
    'eid': 123
    }
person.update(d1)
print(person)

#g) pop function
element = person.pop('eid')
print('The popped element is:', element)
print('The dictionary is:', person)

#h) popitem function
result = person.popitem()
print('Return Value = ', result)
print('person = ', person)

#i) fromkeys function
keys = {'name', 'age', 'salary'}
value = 'unknown'
d2 = dict.fromkeys(keys,value)
print ('d2 dictionary is: ', d2)

#k) Clear function
d2.clear()
print ('now d2 dictionary is:', d2)
