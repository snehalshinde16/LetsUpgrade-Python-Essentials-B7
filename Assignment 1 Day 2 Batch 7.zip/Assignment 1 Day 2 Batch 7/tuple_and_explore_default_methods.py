# Tuple:-
my_tuple = (1, 2, 3)
print(my_tuple)

# tuple can created without parentheses
my_tuple = 3, 4.6, "dog"
print(my_tuple)

# 1. Indexing
my_tuple = ('p','e','r','m','i','t')

print(my_tuple[0])    
print(my_tuple[5])   

# 2. Negative Indexing
my_tuple = ('p', 'e', 'r', 'm', 'i', 't')

print(my_tuple[-1])
print(my_tuple[-6])

# 3. Slicing
my_tuple = ('p','r','o','g','r','a','m','i','z')

# elements 2nd to 4th
print(my_tuple[1:4])

# elements beginning to 2nd
print(my_tuple[:-7])

# elements 8th to end
print(my_tuple[7:])

# elements beginning to end
print(my_tuple[:])

# 3: Deleting a Tuple:-
my_tuple = ('p', 'r', 'o', 'g', 'r', 'a', 'm', 'i', 'z')

# Can delete an entire tuple
del my_tuple

print(my_tuple)

# 4:Tuple Methods:-
my_tuple = ('a', 'p', 'p', 'l', 'e',)

print(my_tuple.count('p'))  
print(my_tuple.index('l'))  

# 5:Other Tuple Operations
# using the keyword "in":-
my_tuple = ('a', 'p', 'p', 'l', 'e',)

# In operation
print('a' in my_tuple)
print('b' in my_tuple)

# Not in operation
print('g' not in my_tuple)

# for loop to iterate through each item in a tuple:-
for name in ('John', 'Kate'):
    print("Hello", name)

