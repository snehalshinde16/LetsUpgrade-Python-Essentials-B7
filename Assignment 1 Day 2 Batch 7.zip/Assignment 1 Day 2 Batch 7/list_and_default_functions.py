# List and it default function

animals = ['cat','dog','rabbit']

# a) append function
animals.append('pig')
print (animals)

# b) count function
count=animals.count('dog')
print ('count of dog is:',count)

# c) insert function
animals.insert(3,'monkey')
print (animals)

# d) index function
index= animals.index('pig')
print ('index of pig is:',index)

# e) reverse function
print ('original list is: ', animals)
animals.reverse()
print ('reverse list is:', animals)

# f) extend function
animals2 = ['tiger','lion','mouse']
animals.extend(animals2)
print ('Extended list is:', animals)

# g) copy function
animalcopy = animals.copy()
print ('copied list is :', animalcopy)

# h) pop function
popped_item = animals.pop(3)
print ('popped item is:', popped_item)
print ('List after popping item :', animals)

# i) remove function
animals.remove('mouse')
print ('list after removing item:', animals)

# j) clear function
animals.clear()
print ('List after clearing items:', animals)

