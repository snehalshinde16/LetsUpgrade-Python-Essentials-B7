# Sets and default functions

# 1:- Removing elements from a set
# A particular item can be removed from a set 
# using the methods discard() and remove().


my_set = {1, 3, 4, 5, 6}
print(my_set)

# discard():-
my_set.discard(4)
print(my_set)

# remove():-
my_set.remove(6)
print(my_set)

# pop() method
my_set = set("HelloWorld")
print(my_set)

print(my_set.pop())



# clear() method
my_set.clear()
print(my_set)

# 2:-Add element in set 

my_set = {1, 3}
print(my_set)

# add() method:-
my_set.add(2)
print(my_set)

# Set operation
# 1:- Union
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}
print(A | B)

# 2:-Intersection
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}
print(A & B)

