# Strings and explore default methods.
#a) Python String Capitalize() method
string = "welcome to Python World"

capitalized_string = string.capitalize()

print('Old String: ', string)
print('Capitalized String:', capitalized_string)

#b) Python String center() method 

string = "Python is awesome"

new_string = string.center(24)

print("Centered String: ", new_string)

#c) Python String Casefold() method
string = "PYTHON IS AWESOME"
# print lowercase string
print("Lowercase string:", string.casefold())

#d) Python String Count() method
statement = "Python is awesome, isn't it?"
substring = "is"
count = statement.count(substring)
print("The count is:", count)

#e). Python string find() method
statement1 = 'Let it be, let it be, let it be'

# i) first occurance of 'let it'(case sensitive)
result = statement1.find('let it')
print("Substring 'let it':", result)

# ii) How to use find()
if (statement1.find('be,') != -1):
    print("Contains substring 'be,'")
else:
    print("Doesn't contain substring")

#f) Python String islower() method
sentence1 = 'this is good'
print(sentence1.islower())

sentence1 = 'this is Not good'
print(sentence1.islower())